set statistics io on
set statistics time on


use WWI
go

SELECT 
    [UnionAll2].[InvoiceID] AS [C1], 
    [UnionAll2].[InvoiceID1] AS [C2], 
    [UnionAll2].[CustomerID] AS [C3], 
    [UnionAll2].[BillToCustomerID] AS [C4], 
    [UnionAll2].[OrderID] AS [C5], 
    [UnionAll2].[DeliveryMethodID] AS [C6], 
    [UnionAll2].[ContactPersonID] AS [C7], 
    [UnionAll2].[AccountsPersonID] AS [C8], 
    [UnionAll2].[SalespersonPersonID] AS [C9], 
    [UnionAll2].[PackedByPersonID] AS [C10], 
    [UnionAll2].[InvoiceDate] AS [C11], 
    [UnionAll2].[CustomerPurchaseOrderNumber] AS [C12], 
    [UnionAll2].[IsCreditNote] AS [C13], 
    [UnionAll2].[CreditNoteReason] AS [C14], 
    [UnionAll2].[Comments] AS [C15], 
    [UnionAll2].[DeliveryInstructions] AS [C16], 
    [UnionAll2].[InternalComments] AS [C17], 
    [UnionAll2].[TotalDryItems] AS [C18], 
    [UnionAll2].[TotalChillerItems] AS [C19], 
    [UnionAll2].[DeliveryRun] AS [C20], 
    [UnionAll2].[RunPosition] AS [C21], 
    [UnionAll2].[ReturnedDeliveryData] AS [C22], 
    [UnionAll2].[ConfirmedDeliveryTime] AS [C23], 
    [UnionAll2].[ConfirmedReceivedBy] AS [C24], 
    [UnionAll2].[LastEditedBy] AS [C25], 
    [UnionAll2].[LastEditedWhen] AS [C26], 
    [UnionAll2].[CustomerID1] AS [C27], 
    [UnionAll2].[CustomerName] AS [C28], 
    [UnionAll2].[BillToCustomerID1] AS [C29], 
    [UnionAll2].[CustomerCategoryID] AS [C30], 
    [UnionAll2].[BuyingGroupID] AS [C31], 
    [UnionAll2].[PrimaryContactPersonID] AS [C32], 
    [UnionAll2].[AlternateContactPersonID] AS [C33], 
    [UnionAll2].[DeliveryMethodID1] AS [C34], 
    [UnionAll2].[DeliveryCityID] AS [C35], 
    [UnionAll2].[PostalCityID] AS [C36], 
    [UnionAll2].[CreditLimit] AS [C37], 
    [UnionAll2].[AccountOpenedDate] AS [C38], 
    [UnionAll2].[StandardDiscountPercentage] AS [C39], 
    [UnionAll2].[IsStatementSent] AS [C40], 
    [UnionAll2].[IsOnCreditHold] AS [C41], 
    [UnionAll2].[PaymentDays] AS [C42], 
    [UnionAll2].[PhoneNumber] AS [C43], 
    [UnionAll2].[FaxNumber] AS [C44], 
    [UnionAll2].[DeliveryRun1] AS [C45], 
    [UnionAll2].[RunPosition1] AS [C46], 
    [UnionAll2].[WebsiteURL] AS [C47], 
    [UnionAll2].[DeliveryAddressLine1] AS [C48], 
    [UnionAll2].[DeliveryAddressLine2] AS [C49], 
    [UnionAll2].[DeliveryPostalCode] AS [C50], 
    [UnionAll2].[DeliveryLocation] AS [C51], 
    [UnionAll2].[PostalAddressLine1] AS [C52], 
    [UnionAll2].[PostalAddressLine2] AS [C53], 
    [UnionAll2].[PostalPostalCode] AS [C54], 
    [UnionAll2].[LastEditedBy1] AS [C55], 
    [UnionAll2].[ValidFrom] AS [C56], 
    [UnionAll2].[ValidTo] AS [C57], 
    [UnionAll2].[DeliveryMethodID2] AS [C58], 
    [UnionAll2].[DeliveryMethodName] AS [C59], 
    [UnionAll2].[LastEditedBy2] AS [C60], 
    [UnionAll2].[ValidFrom1] AS [C61], 
    [UnionAll2].[ValidTo1] AS [C62], 
    [UnionAll2].[C1] AS [C63], 
    [UnionAll2].[CustomerTransactionID] AS [C64], 
    [UnionAll2].[CustomerID2] AS [C65], 
    [UnionAll2].[TransactionTypeID] AS [C66], 
    [UnionAll2].[InvoiceID2] AS [C67], 
    [UnionAll2].[PaymentMethodID] AS [C68], 
    [UnionAll2].[TransactionDate] AS [C69], 
    [UnionAll2].[AmountExcludingTax] AS [C70], 
    [UnionAll2].[TaxAmount] AS [C71], 
    [UnionAll2].[TransactionAmount] AS [C72], 
    [UnionAll2].[OutstandingBalance] AS [C73], 
    [UnionAll2].[FinalizationDate] AS [C74], 
    [UnionAll2].[IsFinalized] AS [C75], 
    [UnionAll2].[LastEditedBy3] AS [C76], 
    [UnionAll2].[LastEditedWhen1] AS [C77], 
    [UnionAll2].[C2] AS [C78], 
    [UnionAll2].[C3] AS [C79], 
    [UnionAll2].[C4] AS [C80], 
    [UnionAll2].[C5] AS [C81], 
    [UnionAll2].[C6] AS [C82], 
    [UnionAll2].[C7] AS [C83], 
    [UnionAll2].[C8] AS [C84], 
    [UnionAll2].[C9] AS [C85], 
    [UnionAll2].[C10] AS [C86], 
    [UnionAll2].[C11] AS [C87], 
    [UnionAll2].[C12] AS [C88], 
    [UnionAll2].[C13] AS [C89], 
    [UnionAll2].[C14] AS [C90], 
    [UnionAll2].[C15] AS [C91], 
    [UnionAll2].[C16] AS [C92], 
    [UnionAll2].[C17] AS [C93], 
    [UnionAll2].[C18] AS [C94], 
    [UnionAll2].[C19] AS [C95], 
    [UnionAll2].[C20] AS [C96], 
    [UnionAll2].[C21] AS [C97], 
    [UnionAll2].[C22] AS [C98], 
    [UnionAll2].[C23] AS [C99], 
    [UnionAll2].[C24] AS [C100], 
    [UnionAll2].[C25] AS [C101]
    FROM  (SELECT 
        CASE WHEN ([Extent4].[CustomerTransactionID] IS NULL) THEN CAST(NULL AS int) ELSE 1 END AS [C1], 
        [Limit1].[InvoiceID] AS [InvoiceID], 
        [Limit1].[InvoiceID] AS [InvoiceID1], 
        [Limit1].[CustomerID1] AS [CustomerID], 
        [Limit1].[BillToCustomerID1] AS [BillToCustomerID], 
        [Limit1].[OrderID] AS [OrderID], 
        [Limit1].[DeliveryMethodID1] AS [DeliveryMethodID], 
        [Limit1].[ContactPersonID] AS [ContactPersonID], 
        [Limit1].[AccountsPersonID] AS [AccountsPersonID], 
        [Limit1].[SalespersonPersonID] AS [SalespersonPersonID], 
        [Limit1].[PackedByPersonID] AS [PackedByPersonID], 
        [Limit1].[InvoiceDate] AS [InvoiceDate], 
        [Limit1].[CustomerPurchaseOrderNumber] AS [CustomerPurchaseOrderNumber], 
        [Limit1].[IsCreditNote] AS [IsCreditNote], 
        [Limit1].[CreditNoteReason] AS [CreditNoteReason], 
        [Limit1].[Comments] AS [Comments], 
        [Limit1].[DeliveryInstructions] AS [DeliveryInstructions], 
        [Limit1].[InternalComments] AS [InternalComments], 
        [Limit1].[TotalDryItems] AS [TotalDryItems], 
        [Limit1].[TotalChillerItems] AS [TotalChillerItems], 
        [Limit1].[DeliveryRun1] AS [DeliveryRun], 
        [Limit1].[RunPosition1] AS [RunPosition], 
        [Limit1].[ReturnedDeliveryData] AS [ReturnedDeliveryData], 
        [Limit1].[ConfirmedDeliveryTime] AS [ConfirmedDeliveryTime], 
        [Limit1].[ConfirmedReceivedBy] AS [ConfirmedReceivedBy], 
        [Limit1].[LastEditedBy1] AS [LastEditedBy], 
        [Limit1].[LastEditedWhen] AS [LastEditedWhen], 
        [Limit1].[CustomerID2] AS [CustomerID1], 
        [Limit1].[CustomerName] AS [CustomerName], 
        [Limit1].[BillToCustomerID2] AS [BillToCustomerID1], 
        [Limit1].[CustomerCategoryID] AS [CustomerCategoryID], 
        [Limit1].[BuyingGroupID] AS [BuyingGroupID], 
        [Limit1].[PrimaryContactPersonID] AS [PrimaryContactPersonID], 
        [Limit1].[AlternateContactPersonID] AS [AlternateContactPersonID], 
        [Limit1].[DeliveryMethodID2] AS [DeliveryMethodID1], 
        [Limit1].[DeliveryCityID] AS [DeliveryCityID], 
        [Limit1].[PostalCityID] AS [PostalCityID], 
        [Limit1].[CreditLimit] AS [CreditLimit], 
        [Limit1].[AccountOpenedDate] AS [AccountOpenedDate], 
        [Limit1].[StandardDiscountPercentage] AS [StandardDiscountPercentage], 
        [Limit1].[IsStatementSent] AS [IsStatementSent], 
        [Limit1].[IsOnCreditHold] AS [IsOnCreditHold], 
        [Limit1].[PaymentDays] AS [PaymentDays], 
        [Limit1].[PhoneNumber] AS [PhoneNumber], 
        [Limit1].[FaxNumber] AS [FaxNumber], 
        [Limit1].[DeliveryRun2] AS [DeliveryRun1], 
        [Limit1].[RunPosition2] AS [RunPosition1], 
        [Limit1].[WebsiteURL] AS [WebsiteURL], 
        [Limit1].[DeliveryAddressLine1] AS [DeliveryAddressLine1], 
        [Limit1].[DeliveryAddressLine2] AS [DeliveryAddressLine2], 
        [Limit1].[DeliveryPostalCode] AS [DeliveryPostalCode], 
        [Limit1].[DeliveryLocation] AS [DeliveryLocation], 
        [Limit1].[PostalAddressLine1] AS [PostalAddressLine1], 
        [Limit1].[PostalAddressLine2] AS [PostalAddressLine2], 
        [Limit1].[PostalPostalCode] AS [PostalPostalCode], 
        [Limit1].[LastEditedBy2] AS [LastEditedBy1], 
        [Limit1].[ValidFrom1] AS [ValidFrom], 
        [Limit1].[ValidTo1] AS [ValidTo], 
        [Limit1].[DeliveryMethodID3] AS [DeliveryMethodID2], 
        [Limit1].[DeliveryMethodName] AS [DeliveryMethodName], 
        [Limit1].[LastEditedBy3] AS [LastEditedBy2], 
        [Limit1].[ValidFrom2] AS [ValidFrom1], 
        [Limit1].[ValidTo2] AS [ValidTo1], 
        [Extent4].[CustomerTransactionID] AS [CustomerTransactionID], 
        [Extent4].[CustomerID] AS [CustomerID2], 
        [Extent4].[TransactionTypeID] AS [TransactionTypeID], 
        [Extent4].[InvoiceID] AS [InvoiceID2], 
        [Extent4].[PaymentMethodID] AS [PaymentMethodID], 
        [Extent4].[TransactionDate] AS [TransactionDate], 
        [Extent4].[AmountExcludingTax] AS [AmountExcludingTax], 
        [Extent4].[TaxAmount] AS [TaxAmount], 
        [Extent4].[TransactionAmount] AS [TransactionAmount], 
        [Extent4].[OutstandingBalance] AS [OutstandingBalance], 
        [Extent4].[FinalizationDate] AS [FinalizationDate], 
        [Extent4].[IsFinalized] AS [IsFinalized], 
        [Extent4].[LastEditedBy] AS [LastEditedBy3], 
        [Extent4].[LastEditedWhen] AS [LastEditedWhen1], 
        CAST(NULL AS int) AS [C2], 
        CAST(NULL AS int) AS [C3], 
        CAST(NULL AS int) AS [C4], 
        CAST(NULL AS varchar(1)) AS [C5], 
        CAST(NULL AS int) AS [C6], 
        CAST(NULL AS int) AS [C7], 
        CAST(NULL AS decimal(18,2)) AS [C8], 
        CAST(NULL AS decimal(18,3)) AS [C9], 
        CAST(NULL AS decimal(18,2)) AS [C10], 
        CAST(NULL AS decimal(18,2)) AS [C11], 
        CAST(NULL AS decimal(18,2)) AS [C12], 
        CAST(NULL AS int) AS [C13], 
        CAST(NULL AS datetime2) AS [C14], 
        CAST(NULL AS int) AS [C15], 
        CAST(NULL AS int) AS [C16], 
        CAST(NULL AS int) AS [C17], 
        CAST(NULL AS int) AS [C18], 
        CAST(NULL AS int) AS [C19], 
        CAST(NULL AS int) AS [C20], 
        CAST(NULL AS int) AS [C21], 
        CAST(NULL AS datetime2) AS [C22], 
        CAST(NULL AS decimal(18,3)) AS [C23], 
        CAST(NULL AS int) AS [C24], 
        CAST(NULL AS datetime2) AS [C25]
        FROM   (SELECT [Extent1].[InvoiceID] AS [InvoiceID]
				, [Extent1].[CustomerID] AS [CustomerID1]
				, [Extent1].[BillToCustomerID] AS [BillToCustomerID1]
				, [Extent1].[OrderID] AS [OrderID]
				, [Extent1].[DeliveryMethodID] AS [DeliveryMethodID1]
				, [Extent1].[ContactPersonID] AS [ContactPersonID]
				, [Extent1].[AccountsPersonID] AS [AccountsPersonID]
				, [Extent1].[SalespersonPersonID] AS [SalespersonPersonID]
				, [Extent1].[PackedByPersonID] AS [PackedByPersonID]
				, [Extent1].[InvoiceDate] AS [InvoiceDate]
				, [Extent1].[CustomerPurchaseOrderNumber] AS [CustomerPurchaseOrderNumber]
				, [Extent1].[IsCreditNote] AS [IsCreditNote]
				, [Extent1].[CreditNoteReason] AS [CreditNoteReason]
				, [Extent1].[Comments] AS [Comments]
				, [Extent1].[DeliveryInstructions] AS [DeliveryInstructions]
				, [Extent1].[InternalComments] AS [InternalComments]
				, [Extent1].[TotalDryItems] AS [TotalDryItems]
				, [Extent1].[TotalChillerItems] AS [TotalChillerItems]
				, [Extent1].[DeliveryRun] AS [DeliveryRun1]
				, [Extent1].[RunPosition] AS [RunPosition1]
				, [Extent1].[ReturnedDeliveryData] AS [ReturnedDeliveryData]
				, [Extent1].[ConfirmedDeliveryTime] AS [ConfirmedDeliveryTime]
				, [Extent1].[ConfirmedReceivedBy] AS [ConfirmedReceivedBy]
				, [Extent1].[LastEditedBy] AS [LastEditedBy1]
				, [Extent1].[LastEditedWhen] AS [LastEditedWhen]
				, [Extent2].[CustomerID] AS [CustomerID2]
				, [Extent2].[CustomerName] AS [CustomerName]
				, [Extent2].[BillToCustomerID] AS [BillToCustomerID2]
				, [Extent2].[CustomerCategoryID] AS [CustomerCategoryID]
				, [Extent2].[BuyingGroupID] AS [BuyingGroupID]
				, [Extent2].[PrimaryContactPersonID] AS [PrimaryContactPersonID]
				, [Extent2].[AlternateContactPersonID] AS [AlternateContactPersonID]
				, [Extent2].[DeliveryMethodID] AS [DeliveryMethodID2]
				, [Extent2].[DeliveryCityID] AS [DeliveryCityID]
				, [Extent2].[PostalCityID] AS [PostalCityID]
				, [Extent2].[CreditLimit] AS [CreditLimit]
				, [Extent2].[AccountOpenedDate] AS [AccountOpenedDate]
				, [Extent2].[StandardDiscountPercentage] AS [StandardDiscountPercentage]
				, [Extent2].[IsStatementSent] AS [IsStatementSent]
				, [Extent2].[IsOnCreditHold] AS [IsOnCreditHold]
				, [Extent2].[PaymentDays] AS [PaymentDays]
				, [Extent2].[PhoneNumber] AS [PhoneNumber]
				, [Extent2].[FaxNumber] AS [FaxNumber]
				, [Extent2].[DeliveryRun] AS [DeliveryRun2]
				, [Extent2].[RunPosition] AS [RunPosition2]
				, [Extent2].[WebsiteURL] AS [WebsiteURL]
				, [Extent2].[DeliveryAddressLine1] AS [DeliveryAddressLine1]
				, [Extent2].[DeliveryAddressLine2] AS [DeliveryAddressLine2]
				, [Extent2].[DeliveryPostalCode] AS [DeliveryPostalCode]
				, [Extent2].[DeliveryLocation] AS [DeliveryLocation]
				, [Extent2].[PostalAddressLine1] AS [PostalAddressLine1]
				, [Extent2].[PostalAddressLine2] AS [PostalAddressLine2]
				, [Extent2].[PostalPostalCode] AS [PostalPostalCode]
				, [Extent2].[LastEditedBy] AS [LastEditedBy2]
				, [Extent2].[ValidFrom] AS [ValidFrom1]
				, [Extent2].[ValidTo] AS [ValidTo1]
				, [Extent3].[DeliveryMethodID] AS [DeliveryMethodID3]
				, [Extent3].[DeliveryMethodName] AS [DeliveryMethodName]
				, [Extent3].[LastEditedBy] AS [LastEditedBy3]
				, [Extent3].[ValidFrom] AS [ValidFrom2]
				, [Extent3].[ValidTo] AS [ValidTo2]
            FROM   [Sales].[Invoices] AS [Extent1]
            INNER JOIN [Sales].[Customers] AS [Extent2] ON [Extent1].[BillToCustomerID] = [Extent2].[CustomerID]
            INNER JOIN [Application].[DeliveryMethods] AS [Extent3] ON [Extent1].[DeliveryMethodID] = [Extent3].[DeliveryMethodID] ) AS [Limit1]
        LEFT OUTER JOIN [Sales].[CustomerTransactions] AS [Extent4] ON [Limit1].[InvoiceID] = [Extent4].[InvoiceID]
    UNION ALL
        SELECT 
        2 AS [C1], 
        [Limit2].[InvoiceID] AS [InvoiceID], 
        [Limit2].[InvoiceID] AS [InvoiceID1], 
        [Limit2].[CustomerID3] AS [CustomerID], 
        [Limit2].[BillToCustomerID3] AS [BillToCustomerID], 
        [Limit2].[OrderID] AS [OrderID], 
        [Limit2].[DeliveryMethodID4] AS [DeliveryMethodID], 
        [Limit2].[ContactPersonID] AS [ContactPersonID], 
        [Limit2].[AccountsPersonID] AS [AccountsPersonID], 
        [Limit2].[SalespersonPersonID] AS [SalespersonPersonID], 
        [Limit2].[PackedByPersonID] AS [PackedByPersonID], 
        [Limit2].[InvoiceDate] AS [InvoiceDate], 
        [Limit2].[CustomerPurchaseOrderNumber] AS [CustomerPurchaseOrderNumber], 
        [Limit2].[IsCreditNote] AS [IsCreditNote], 
        [Limit2].[CreditNoteReason] AS [CreditNoteReason], 
        [Limit2].[Comments] AS [Comments], 
        [Limit2].[DeliveryInstructions] AS [DeliveryInstructions], 
        [Limit2].[InternalComments] AS [InternalComments], 
        [Limit2].[TotalDryItems] AS [TotalDryItems], 
        [Limit2].[TotalChillerItems] AS [TotalChillerItems], 
        [Limit2].[DeliveryRun3] AS [DeliveryRun], 
        [Limit2].[RunPosition3] AS [RunPosition], 
        [Limit2].[ReturnedDeliveryData] AS [ReturnedDeliveryData], 
        [Limit2].[ConfirmedDeliveryTime] AS [ConfirmedDeliveryTime], 
        [Limit2].[ConfirmedReceivedBy] AS [ConfirmedReceivedBy], 
        [Limit2].[LastEditedBy4] AS [LastEditedBy], 
        [Limit2].[LastEditedWhen] AS [LastEditedWhen], 
        [Limit2].[CustomerID4] AS [CustomerID1], 
        [Limit2].[CustomerName] AS [CustomerName], 
        [Limit2].[BillToCustomerID4] AS [BillToCustomerID1], 
        [Limit2].[CustomerCategoryID] AS [CustomerCategoryID], 
        [Limit2].[BuyingGroupID] AS [BuyingGroupID], 
        [Limit2].[PrimaryContactPersonID] AS [PrimaryContactPersonID], 
        [Limit2].[AlternateContactPersonID] AS [AlternateContactPersonID], 
        [Limit2].[DeliveryMethodID5] AS [DeliveryMethodID1], 
        [Limit2].[DeliveryCityID] AS [DeliveryCityID], 
        [Limit2].[PostalCityID] AS [PostalCityID], 
        [Limit2].[CreditLimit] AS [CreditLimit], 
        [Limit2].[AccountOpenedDate] AS [AccountOpenedDate], 
        [Limit2].[StandardDiscountPercentage] AS [StandardDiscountPercentage], 
        [Limit2].[IsStatementSent] AS [IsStatementSent], 
        [Limit2].[IsOnCreditHold] AS [IsOnCreditHold], 
        [Limit2].[PaymentDays] AS [PaymentDays], 
        [Limit2].[PhoneNumber] AS [PhoneNumber], 
        [Limit2].[FaxNumber] AS [FaxNumber], 
        [Limit2].[DeliveryRun4] AS [DeliveryRun1], 
        [Limit2].[RunPosition4] AS [RunPosition1], 
        [Limit2].[WebsiteURL] AS [WebsiteURL], 
        [Limit2].[DeliveryAddressLine1] AS [DeliveryAddressLine1], 
        [Limit2].[DeliveryAddressLine2] AS [DeliveryAddressLine2], 
        [Limit2].[DeliveryPostalCode] AS [DeliveryPostalCode], 
        [Limit2].[DeliveryLocation] AS [DeliveryLocation], 
        [Limit2].[PostalAddressLine1] AS [PostalAddressLine1], 
        [Limit2].[PostalAddressLine2] AS [PostalAddressLine2], 
        [Limit2].[PostalPostalCode] AS [PostalPostalCode], 
        [Limit2].[LastEditedBy5] AS [LastEditedBy1], 
        [Limit2].[ValidFrom3] AS [ValidFrom], 
        [Limit2].[ValidTo3] AS [ValidTo], 
        [Limit2].[DeliveryMethodID6] AS [DeliveryMethodID2], 
        [Limit2].[DeliveryMethodName] AS [DeliveryMethodName], 
        [Limit2].[LastEditedBy6] AS [LastEditedBy2], 
        [Limit2].[ValidFrom4] AS [ValidFrom1], 
        [Limit2].[ValidTo4] AS [ValidTo1], 
        CAST(NULL AS int) AS [C2], 
        CAST(NULL AS int) AS [C3], 
        CAST(NULL AS int) AS [C4], 
        CAST(NULL AS int) AS [C5], 
        CAST(NULL AS int) AS [C6], 
        CAST(NULL AS datetime2) AS [C7], 
        CAST(NULL AS decimal(18,2)) AS [C8], 
        CAST(NULL AS decimal(18,2)) AS [C9], 
        CAST(NULL AS decimal(18,2)) AS [C10], 
        CAST(NULL AS decimal(18,2)) AS [C11], 
        CAST(NULL AS datetime2) AS [C12], 
        CAST(NULL AS bit) AS [C13], 
        CAST(NULL AS int) AS [C14], 
        CAST(NULL AS datetime2) AS [C15], 
        [Extent8].[InvoiceLineID] AS [InvoiceLineID], 
        [Extent8].[InvoiceID] AS [InvoiceID2], 
        [Extent8].[StockItemID] AS [StockItemID], 
        [Extent8].[Description] AS [Description], 
        [Extent8].[PackageTypeID] AS [PackageTypeID], 
        [Extent8].[Quantity] AS [Quantity], 
        [Extent8].[UnitPrice] AS [UnitPrice], 
        [Extent8].[TaxRate] AS [TaxRate], 
        [Extent8].[TaxAmount] AS [TaxAmount], 
        [Extent8].[LineProfit] AS [LineProfit], 
        [Extent8].[ExtendedPrice] AS [ExtendedPrice], 
        [Extent8].[LastEditedBy] AS [LastEditedBy3], 
        [Extent8].[LastEditedWhen] AS [LastEditedWhen1], 
        CAST(NULL AS int) AS [C16], 
        CAST(NULL AS int) AS [C17], 
        CAST(NULL AS int) AS [C18], 
        CAST(NULL AS int) AS [C19], 
        CAST(NULL AS int) AS [C20], 
        CAST(NULL AS int) AS [C21], 
        CAST(NULL AS int) AS [C22], 
        CAST(NULL AS datetime2) AS [C23], 
        CAST(NULL AS decimal(18,3)) AS [C24], 
        CAST(NULL AS int) AS [C25], 
        CAST(NULL AS datetime2) AS [C26]
        FROM   (SELECT [Extent5].[InvoiceID] AS [InvoiceID]
					, [Extent5].[CustomerID] AS [CustomerID3]
					, [Extent5].[BillToCustomerID] AS [BillToCustomerID3]
					, [Extent5].[OrderID] AS [OrderID]
					, [Extent5].[DeliveryMethodID] AS [DeliveryMethodID4]
					, [Extent5].[ContactPersonID] AS [ContactPersonID]
					, [Extent5].[AccountsPersonID] AS [AccountsPersonID]
					, [Extent5].[SalespersonPersonID] AS [SalespersonPersonID]
					, [Extent5].[PackedByPersonID] AS [PackedByPersonID]
					, [Extent5].[InvoiceDate] AS [InvoiceDate]
					, [Extent5].[CustomerPurchaseOrderNumber] AS [CustomerPurchaseOrderNumber]
					, [Extent5].[IsCreditNote] AS [IsCreditNote]
					, [Extent5].[CreditNoteReason] AS [CreditNoteReason]
					, [Extent5].[Comments] AS [Comments]
					, [Extent5].[DeliveryInstructions] AS [DeliveryInstructions]
					, [Extent5].[InternalComments] AS [InternalComments]
					, [Extent5].[TotalDryItems] AS [TotalDryItems]
					, [Extent5].[TotalChillerItems] AS [TotalChillerItems]
					, [Extent5].[DeliveryRun] AS [DeliveryRun3]
					, [Extent5].[RunPosition] AS [RunPosition3]
					, [Extent5].[ReturnedDeliveryData] AS [ReturnedDeliveryData]
					, [Extent5].[ConfirmedDeliveryTime] AS [ConfirmedDeliveryTime]
					, [Extent5].[ConfirmedReceivedBy] AS [ConfirmedReceivedBy]
					, [Extent5].[LastEditedBy] AS [LastEditedBy4]
					, [Extent5].[LastEditedWhen] AS [LastEditedWhen]
					, [Extent6].[CustomerID] AS [CustomerID4]
					, [Extent6].[CustomerName] AS [CustomerName]
					, [Extent6].[BillToCustomerID] AS [BillToCustomerID4]
					, [Extent6].[CustomerCategoryID] AS [CustomerCategoryID]
					, [Extent6].[BuyingGroupID] AS [BuyingGroupID]
					, [Extent6].[PrimaryContactPersonID] AS [PrimaryContactPersonID]
					, [Extent6].[AlternateContactPersonID] AS [AlternateContactPersonID]
					, [Extent6].[DeliveryMethodID] AS [DeliveryMethodID5]
					, [Extent6].[DeliveryCityID] AS [DeliveryCityID]
					, [Extent6].[PostalCityID] AS [PostalCityID]
					, [Extent6].[CreditLimit] AS [CreditLimit]
					, [Extent6].[AccountOpenedDate] AS [AccountOpenedDate]
					, [Extent6].[StandardDiscountPercentage] AS [StandardDiscountPercentage]
					, [Extent6].[IsStatementSent] AS [IsStatementSent]
					, [Extent6].[IsOnCreditHold] AS [IsOnCreditHold]
					, [Extent6].[PaymentDays] AS [PaymentDays]
					, [Extent6].[PhoneNumber] AS [PhoneNumber]
					, [Extent6].[FaxNumber] AS [FaxNumber]
					, [Extent6].[DeliveryRun] AS [DeliveryRun4]
					, [Extent6].[RunPosition] AS [RunPosition4]
					, [Extent6].[WebsiteURL] AS [WebsiteURL]
					, [Extent6].[DeliveryAddressLine1] AS [DeliveryAddressLine1]
					, [Extent6].[DeliveryAddressLine2] AS [DeliveryAddressLine2]
					, [Extent6].[DeliveryPostalCode] AS [DeliveryPostalCode]
					, [Extent6].[DeliveryLocation] AS [DeliveryLocation]
					, [Extent6].[PostalAddressLine1] AS [PostalAddressLine1]
					, [Extent6].[PostalAddressLine2] AS [PostalAddressLine2]
					, [Extent6].[PostalPostalCode] AS [PostalPostalCode]
					, [Extent6].[LastEditedBy] AS [LastEditedBy5]
					, [Extent6].[ValidFrom] AS [ValidFrom3]
					, [Extent6].[ValidTo] AS [ValidTo3]
					, [Extent7].[DeliveryMethodID] AS [DeliveryMethodID6]
					, [Extent7].[DeliveryMethodName] AS [DeliveryMethodName]
					, [Extent7].[LastEditedBy] AS [LastEditedBy6]
					, [Extent7].[ValidFrom] AS [ValidFrom4]
					, [Extent7].[ValidTo] AS [ValidTo4]
            FROM   [Sales].[Invoices] AS [Extent5]
            INNER JOIN [Sales].[Customers] AS [Extent6] ON [Extent5].[BillToCustomerID] = [Extent6].[CustomerID]
            INNER JOIN [Application].[DeliveryMethods] AS [Extent7] ON [Extent5].[DeliveryMethodID] = [Extent7].[DeliveryMethodID] ) AS [Limit2]
        INNER JOIN [Sales].[InvoiceLines] AS [Extent8] ON [Limit2].[InvoiceID] = [Extent8].[InvoiceID]
    UNION ALL
        SELECT 
        3 AS [C1], 
        [Limit3].[InvoiceID] AS [InvoiceID], 
        [Limit3].[InvoiceID] AS [InvoiceID1], 
        [Limit3].[CustomerID5] AS [CustomerID], 
        [Limit3].[BillToCustomerID5] AS [BillToCustomerID], 
        [Limit3].[OrderID] AS [OrderID], 
        [Limit3].[DeliveryMethodID7] AS [DeliveryMethodID], 
        [Limit3].[ContactPersonID] AS [ContactPersonID], 
        [Limit3].[AccountsPersonID] AS [AccountsPersonID], 
        [Limit3].[SalespersonPersonID] AS [SalespersonPersonID], 
        [Limit3].[PackedByPersonID] AS [PackedByPersonID], 
        [Limit3].[InvoiceDate] AS [InvoiceDate], 
        [Limit3].[CustomerPurchaseOrderNumber] AS [CustomerPurchaseOrderNumber], 
        [Limit3].[IsCreditNote] AS [IsCreditNote], 
        [Limit3].[CreditNoteReason] AS [CreditNoteReason], 
        [Limit3].[Comments] AS [Comments], 
        [Limit3].[DeliveryInstructions] AS [DeliveryInstructions], 
        [Limit3].[InternalComments] AS [InternalComments], 
        [Limit3].[TotalDryItems] AS [TotalDryItems], 
        [Limit3].[TotalChillerItems] AS [TotalChillerItems], 
        [Limit3].[DeliveryRun5] AS [DeliveryRun], 
        [Limit3].[RunPosition5] AS [RunPosition], 
        [Limit3].[ReturnedDeliveryData] AS [ReturnedDeliveryData], 
        [Limit3].[ConfirmedDeliveryTime] AS [ConfirmedDeliveryTime], 
        [Limit3].[ConfirmedReceivedBy] AS [ConfirmedReceivedBy], 
        [Limit3].[LastEditedBy7] AS [LastEditedBy], 
        [Limit3].[LastEditedWhen] AS [LastEditedWhen], 
        [Limit3].[CustomerID6] AS [CustomerID1], 
        [Limit3].[CustomerName] AS [CustomerName], 
        [Limit3].[BillToCustomerID6] AS [BillToCustomerID1], 
        [Limit3].[CustomerCategoryID] AS [CustomerCategoryID], 
        [Limit3].[BuyingGroupID] AS [BuyingGroupID], 
        [Limit3].[PrimaryContactPersonID] AS [PrimaryContactPersonID], 
        [Limit3].[AlternateContactPersonID] AS [AlternateContactPersonID], 
        [Limit3].[DeliveryMethodID8] AS [DeliveryMethodID1], 
        [Limit3].[DeliveryCityID] AS [DeliveryCityID], 
        [Limit3].[PostalCityID] AS [PostalCityID], 
        [Limit3].[CreditLimit] AS [CreditLimit], 
        [Limit3].[AccountOpenedDate] AS [AccountOpenedDate], 
        [Limit3].[StandardDiscountPercentage] AS [StandardDiscountPercentage], 
        [Limit3].[IsStatementSent] AS [IsStatementSent], 
        [Limit3].[IsOnCreditHold] AS [IsOnCreditHold], 
        [Limit3].[PaymentDays] AS [PaymentDays], 
        [Limit3].[PhoneNumber] AS [PhoneNumber], 
        [Limit3].[FaxNumber] AS [FaxNumber], 
        [Limit3].[DeliveryRun6] AS [DeliveryRun1], 
        [Limit3].[RunPosition6] AS [RunPosition1], 
        [Limit3].[WebsiteURL] AS [WebsiteURL], 
        [Limit3].[DeliveryAddressLine1] AS [DeliveryAddressLine1], 
        [Limit3].[DeliveryAddressLine2] AS [DeliveryAddressLine2], 
        [Limit3].[DeliveryPostalCode] AS [DeliveryPostalCode], 
        [Limit3].[DeliveryLocation] AS [DeliveryLocation], 
        [Limit3].[PostalAddressLine1] AS [PostalAddressLine1], 
        [Limit3].[PostalAddressLine2] AS [PostalAddressLine2], 
        [Limit3].[PostalPostalCode] AS [PostalPostalCode], 
        [Limit3].[LastEditedBy8] AS [LastEditedBy1], 
        [Limit3].[ValidFrom5] AS [ValidFrom], 
        [Limit3].[ValidTo5] AS [ValidTo], 
        [Limit3].[DeliveryMethodID9] AS [DeliveryMethodID2], 
        [Limit3].[DeliveryMethodName] AS [DeliveryMethodName], 
        [Limit3].[LastEditedBy9] AS [LastEditedBy2], 
        [Limit3].[ValidFrom6] AS [ValidFrom1], 
        [Limit3].[ValidTo6] AS [ValidTo1], 
        CAST(NULL AS int) AS [C2], 
        CAST(NULL AS int) AS [C3], 
        CAST(NULL AS int) AS [C4], 
        CAST(NULL AS int) AS [C5], 
        CAST(NULL AS int) AS [C6], 
        CAST(NULL AS datetime2) AS [C7], 
        CAST(NULL AS decimal(18,2)) AS [C8], 
        CAST(NULL AS decimal(18,2)) AS [C9], 
        CAST(NULL AS decimal(18,2)) AS [C10], 
        CAST(NULL AS decimal(18,2)) AS [C11], 
        CAST(NULL AS datetime2) AS [C12], 
        CAST(NULL AS bit) AS [C13], 
        CAST(NULL AS int) AS [C14], 
        CAST(NULL AS datetime2) AS [C15], 
        CAST(NULL AS int) AS [C16], 
        CAST(NULL AS int) AS [C17], 
        CAST(NULL AS int) AS [C18], 
        CAST(NULL AS varchar(1)) AS [C19], 
        CAST(NULL AS int) AS [C20], 
        CAST(NULL AS int) AS [C21], 
        CAST(NULL AS decimal(18,2)) AS [C22], 
        CAST(NULL AS decimal(18,3)) AS [C23], 
        CAST(NULL AS decimal(18,2)) AS [C24], 
        CAST(NULL AS decimal(18,2)) AS [C25], 
        CAST(NULL AS decimal(18,2)) AS [C26], 
        CAST(NULL AS int) AS [C27], 
        CAST(NULL AS datetime2) AS [C28], 
        [Extent12].[StockItemTransactionID] AS [StockItemTransactionID], 
        [Extent12].[StockItemID] AS [StockItemID], 
        [Extent12].[TransactionTypeID] AS [TransactionTypeID], 
        [Extent12].[CustomerID] AS [CustomerID2], 
        [Extent12].[InvoiceID] AS [InvoiceID2], 
        [Extent12].[SupplierID] AS [SupplierID], 
        [Extent12].[PurchaseOrderID] AS [PurchaseOrderID], 
        [Extent12].[TransactionOccurredWhen] AS [TransactionOccurredWhen], 
        [Extent12].[Quantity] AS [Quantity], 
        [Extent12].[LastEditedBy] AS [LastEditedBy3], 
        [Extent12].[LastEditedWhen] AS [LastEditedWhen1]
        FROM   (SELECT [Extent9].[InvoiceID] AS [InvoiceID]
				, [Extent9].[CustomerID] AS [CustomerID5]
				, [Extent9].[BillToCustomerID] AS [BillToCustomerID5]
				, [Extent9].[OrderID] AS [OrderID]
				, [Extent9].[DeliveryMethodID] AS [DeliveryMethodID7]
				, [Extent9].[ContactPersonID] AS [ContactPersonID]
				, [Extent9].[AccountsPersonID] AS [AccountsPersonID]
				, [Extent9].[SalespersonPersonID] AS [SalespersonPersonID]
				, [Extent9].[PackedByPersonID] AS [PackedByPersonID]
				, [Extent9].[InvoiceDate] AS [InvoiceDate]
				, [Extent9].[CustomerPurchaseOrderNumber] AS [CustomerPurchaseOrderNumber]
				, [Extent9].[IsCreditNote] AS [IsCreditNote]
				, [Extent9].[CreditNoteReason] AS [CreditNoteReason]
				, [Extent9].[Comments] AS [Comments]
				, [Extent9].[DeliveryInstructions] AS [DeliveryInstructions]
				, [Extent9].[InternalComments] AS [InternalComments]
				, [Extent9].[TotalDryItems] AS [TotalDryItems]
				, [Extent9].[TotalChillerItems] AS [TotalChillerItems]
				, [Extent9].[DeliveryRun] AS [DeliveryRun5]
				, [Extent9].[RunPosition] AS [RunPosition5]
				, [Extent9].[ReturnedDeliveryData] AS [ReturnedDeliveryData]
				, [Extent9].[ConfirmedDeliveryTime] AS [ConfirmedDeliveryTime]
				, [Extent9].[ConfirmedReceivedBy] AS [ConfirmedReceivedBy]
				, [Extent9].[LastEditedBy] AS [LastEditedBy7]
				, [Extent9].[LastEditedWhen] AS [LastEditedWhen]
				, [Extent10].[CustomerID] AS [CustomerID6]
				, [Extent10].[CustomerName] AS [CustomerName]
				, [Extent10].[BillToCustomerID] AS [BillToCustomerID6]
				, [Extent10].[CustomerCategoryID] AS [CustomerCategoryID]
				, [Extent10].[BuyingGroupID] AS [BuyingGroupID]
				, [Extent10].[PrimaryContactPersonID] AS [PrimaryContactPersonID]
				, [Extent10].[AlternateContactPersonID] AS [AlternateContactPersonID]
				, [Extent10].[DeliveryMethodID] AS [DeliveryMethodID8]
				, [Extent10].[DeliveryCityID] AS [DeliveryCityID]
				, [Extent10].[PostalCityID] AS [PostalCityID]
				, [Extent10].[CreditLimit] AS [CreditLimit]
				, [Extent10].[AccountOpenedDate] AS [AccountOpenedDate]
				, [Extent10].[StandardDiscountPercentage] AS [StandardDiscountPercentage]
				, [Extent10].[IsStatementSent] AS [IsStatementSent]
				, [Extent10].[IsOnCreditHold] AS [IsOnCreditHold]
				, [Extent10].[PaymentDays] AS [PaymentDays]
				, [Extent10].[PhoneNumber] AS [PhoneNumber]
				, [Extent10].[FaxNumber] AS [FaxNumber]
				, [Extent10].[DeliveryRun] AS [DeliveryRun6]
				, [Extent10].[RunPosition] AS [RunPosition6]
				, [Extent10].[WebsiteURL] AS [WebsiteURL]
				, [Extent10].[DeliveryAddressLine1] AS [DeliveryAddressLine1]
				, [Extent10].[DeliveryAddressLine2] AS [DeliveryAddressLine2]
				, [Extent10].[DeliveryPostalCode] AS [DeliveryPostalCode]
				, [Extent10].[DeliveryLocation] AS [DeliveryLocation]
				, [Extent10].[PostalAddressLine1] AS [PostalAddressLine1]
				, [Extent10].[PostalAddressLine2] AS [PostalAddressLine2]
				, [Extent10].[PostalPostalCode] AS [PostalPostalCode]
				, [Extent10].[LastEditedBy] AS [LastEditedBy8]
				, [Extent10].[ValidFrom] AS [ValidFrom5]
				, [Extent10].[ValidTo] AS [ValidTo5]
				, [Extent11].[DeliveryMethodID] AS [DeliveryMethodID9]
				, [Extent11].[DeliveryMethodName] AS [DeliveryMethodName]
				, [Extent11].[LastEditedBy] AS [LastEditedBy9]
				, [Extent11].[ValidFrom] AS [ValidFrom6]
				, [Extent11].[ValidTo] AS [ValidTo6]
            FROM   [Sales].[Invoices] AS [Extent9]
            INNER JOIN [Sales].[Customers] AS [Extent10] ON [Extent9].[BillToCustomerID] = [Extent10].[CustomerID]
            INNER JOIN [Application].[DeliveryMethods] AS [Extent11] ON [Extent9].[DeliveryMethodID] = [Extent11].[DeliveryMethodID] ) AS [Limit3]
        INNER JOIN [Warehouse].[StockItemTransactions] AS [Extent12] ON [Limit3].[InvoiceID] = [Extent12].[InvoiceID]) AS [UnionAll2]
    ORDER BY [UnionAll2].[InvoiceID1] ASC, [UnionAll2].[CustomerID1] ASC, [UnionAll2].[DeliveryMethodID2] ASC, [UnionAll2].[C1] ASC
