--set statistics io on
--set statistics time on
use WWI;


;with x as (select count(ol.OrderID) order_count, ol.OrderID
from sales.OrderLines ol
group by ol.OrderID)
select top 1000 orderid
into #orders
from x
order by order_count desc

--select * from #orders

----------------declare orderid-----------
--declare @orderid int
--set @orderid = 26866

declare @order_id int, @stockitem_id int

CREATE TABLE #test(
	[unitprice] [decimal](18, 2) NULL,
	[RecommendedRetailPrice] [decimal](18, 2) NULL,
	[Quantity] [int] NOT NULL,
	[PickedQuantity] [int] NOT NULL,
	[TaxRate] [decimal](18, 3) NULL,
	[TaxAmount] [decimal](18, 2) NULL,
	[LineProfit] [decimal](18, 2) NULL,
	[taxmultiplier] [decimal](23, 7) NULL,
	[totalprice] [decimal](29, 2) NULL,
	[totalpriceplustax] [decimal](38, 6) NULL,
	[totalpriceplustax2] [decimal](18, 2) NULL) 


declare cursor_OrderPrices cursor
for 
select ol.OrderID, ol.StockItemID
from sales.OrderLines ol
join #orders o on ol.OrderID = o.OrderID

open cursor_OrderPrices


FETCH NEXT FROM cursor_OrderPrices 
INTO @order_id, @stockitem_id  

WHILE @@FETCH_STATUS = 0  
BEGIN  

insert into #test
select si.unitprice
, si.RecommendedRetailPrice
,ol.Quantity
,ol.PickedQuantity
,il.TaxRate
,il.TaxAmount
,il.LineProfit
,(il.taxrate/100)+1 as taxmultiplier
,il.Quantity * il.UnitPrice as totalprice
,(il.Quantity * il.UnitPrice)*((il.taxrate/100)+1) as totalpriceplustax
,convert(decimal(18,2),(il.Quantity * il.UnitPrice)*((il.taxrate/100)+1)) as totalpriceplustax2
from sales.OrderLines ol
left outer join sales.Orders o on ol.OrderID = o.OrderID
left outer join Warehouse.StockItems si on ol.StockItemID = si.StockItemID
left outer join sales.Invoices i on o.OrderID = i.OrderID
left outer join Sales.InvoiceLines il on i.InvoiceID = il.InvoiceID and ol.StockItemID = il.StockItemID
left outer join sales.CustomerTransactions ct on i.InvoiceID = ct.InvoiceID
where ol.orderid = @order_id and ol.StockItemID = @stockitem_id


FETCH NEXT FROM cursor_OrderPrices   
INTO @order_id, @stockitem_id  
END   
CLOSE cursor_OrderPrices;  
DEALLOCATE cursor_OrderPrices;


select * from #test

drop table #test
drop table #orders
