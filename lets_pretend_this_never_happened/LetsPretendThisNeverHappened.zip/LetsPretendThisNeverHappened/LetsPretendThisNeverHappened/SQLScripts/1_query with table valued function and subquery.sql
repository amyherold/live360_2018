set statistics io on
set statistics time on

use WWI
go



----------------declare orderid-----------
declare @orderid int
set @orderid = 26866




--------------query with table defined funtion------------
select fnOrder.unitprice
,fnOrder.RecommendedRetailPrice
,fnOrder.UnitPrice
,fnOrder.Quantity
,fnOrder.PickedQuantity
--,il.Quantity
--,il.UnitPrice
,fnOrder.TaxRate
,fnOrder.TaxAmount
,fnOrder.LineProfit
,fnOrder.TaxRateMultiplier
,fnOrder.totalPrice
,fnOrder.TotalPricePlusTax
,fnOrder.TotalPricePlusTax2
,ct.*
,il.*
, ol.* 
from sales.OrderLines ol
left outer join sales.Orders o on ol.OrderID = o.OrderID
left outer join Warehouse.StockItems si on ol.StockItemID = si.StockItemID
left outer join sales.Invoices i on o.OrderID = i.OrderID
left outer join Sales.InvoiceLines il on i.InvoiceID = il.InvoiceID and ol.StockItemID = il.StockItemID
left outer join sales.CustomerTransactions ct on i.InvoiceID = ct.InvoiceID
outer apply udf_OrderPrices(ol.orderid,ol.StockItemID) fnOrder
where ol.orderid = @orderid




--------------------query without the table function-----------------
select si.unitprice, si.RecommendedRetailPrice
,ol.UnitPrice
,ol.Quantity
,ol.PickedQuantity
,il.Quantity
,il.UnitPrice
,il.TaxRate
,il.TaxAmount
,il.LineProfit
,(il.taxrate/100)+1
,il.Quantity * il.UnitPrice as totalprice
,(il.Quantity * il.UnitPrice)*((il.taxrate/100)+1) as totalpriceplustax
,convert(decimal(18,2),(il.Quantity * il.UnitPrice)*((il.taxrate/100)+1)) as totalpriceplustax2
,ct.*
,il.*
, ol.* 
from sales.OrderLines ol
left outer join sales.Orders o on ol.OrderID = o.OrderID
left outer join Warehouse.StockItems si on ol.StockItemID = si.StockItemID
left outer join sales.Invoices i on o.OrderID = i.OrderID
left outer join Sales.InvoiceLines il on i.InvoiceID = il.InvoiceID and ol.StockItemID = il.StockItemID
left outer join sales.CustomerTransactions ct on i.InvoiceID = ct.InvoiceID
where ol.orderid = @orderid





----------------query with a subquery------------
--select fnOrder.unitprice
--,fnOrder.RecommendedRetailPrice
--,fnOrder.UnitPrice
--,fnOrder.Quantity
--,fnOrder.PickedQuantity
----,il.Quantity
----,il.UnitPrice
--,fnOrder.TaxRate
--,fnOrder.TaxAmount
--,fnOrder.LineProfit
--,fnOrder.TaxRateMultiplier
--,fnOrder.totalPrice
--,fnOrder.TotalPricePlusTax
--,fnOrder.TotalPricePlusTax2
--,ct.*
--,il.*
--, ol.* 
--from sales.OrderLines ol
--left outer join sales.Orders o on ol.OrderID = o.OrderID
--left outer join Warehouse.StockItems si on ol.StockItemID = si.StockItemID
--left outer join sales.Invoices i on o.OrderID = i.OrderID
--left outer join Sales.InvoiceLines il on i.InvoiceID = il.InvoiceID and ol.StockItemID = il.StockItemID
--left outer join sales.CustomerTransactions ct on i.InvoiceID = ct.InvoiceID
--outer apply udf_OrderPrices(ol.orderid) fnOrder
--where ol.orderid = @orderid



select subq.unitprice
,subq.RecommendedRetailPrice
,subq.UnitPrice
,subq.Quantity
,subq.PickedQuantity
,subq.TaxRate
,subq.TaxAmount
,subq.LineProfit
,(il.taxrate/100)+1
,subq.totalprice
,subq.totalpriceplustax
,subq.totalpriceplustax2
,ct.*
,il.*
--,ct.*
, ol.* 
from sales.OrderLines ol
left outer join sales.Orders o on ol.OrderID = o.OrderID
left outer join Warehouse.StockItems si on ol.StockItemID = si.StockItemID
left outer join sales.Invoices i on o.OrderID = i.OrderID
left outer join Sales.InvoiceLines il on i.InvoiceID = il.InvoiceID and ol.StockItemID = il.StockItemID
left outer join sales.CustomerTransactions ct on i.InvoiceID = ct.InvoiceID
left outer join (select ol.OrderID 
					,ol.StockItemID
					,si.unitprice
					,si.RecommendedRetailPrice
					,ol.Quantity
					,ol.PickedQuantity
					,il.TaxRate
					,il.TaxAmount
					,il.LineProfit
					,(il.taxrate/100)+1 as TaxRateMultiplier
					,il.Quantity * il.UnitPrice as totalprice
					,(il.Quantity * il.UnitPrice)*((il.taxrate/100)+1) as totalpriceplustax
					,convert(decimal(18,2),(il.Quantity * il.UnitPrice)*((il.taxrate/100)+1)) as totalpriceplustax2
					from sales.OrderLines ol
					left outer join sales.Orders o on ol.OrderID = o.OrderID
					left outer join Warehouse.StockItems si on ol.StockItemID = si.StockItemID
					left outer join sales.Invoices i on o.OrderID = i.OrderID
					left outer join Sales.InvoiceLines il on i.InvoiceID = il.InvoiceID and ol.StockItemID = il.StockItemID
					left outer join sales.CustomerTransactions ct on i.InvoiceID = ct.InvoiceID) subq on ol.orderid = subq.orderid and ol.StockItemID = subq.StockItemID
where ol.orderid = @orderid


