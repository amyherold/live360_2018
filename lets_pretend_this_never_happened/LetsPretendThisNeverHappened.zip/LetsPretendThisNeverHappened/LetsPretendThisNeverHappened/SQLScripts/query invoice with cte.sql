set statistics io on
set statistics time on



;WITH CTE AS
(
		SELECT [Extent1].[InvoiceID] AS [InvoiceID]
				, [Extent1].[CustomerID] AS [CustomerID1]
				, [Extent1].[BillToCustomerID] AS [BillToCustomerID1]
				, [Extent1].[OrderID] AS [OrderID]
				, [Extent1].[DeliveryMethodID] AS [DeliveryMethodID1]
				, [Extent1].[ContactPersonID] AS [ContactPersonID]
				, [Extent1].[AccountsPersonID] AS [AccountsPersonID]
				, [Extent1].[SalespersonPersonID] AS [SalespersonPersonID]
				, [Extent1].[PackedByPersonID] AS [PackedByPersonID]
				, [Extent1].[InvoiceDate] AS [InvoiceDate]
				, [Extent1].[CustomerPurchaseOrderNumber] AS [CustomerPurchaseOrderNumber]
				, [Extent1].[IsCreditNote] AS [IsCreditNote]
				, [Extent1].[CreditNoteReason] AS [CreditNoteReason]
				, [Extent1].[Comments] AS [Comments]
				, [Extent1].[DeliveryInstructions] AS [DeliveryInstructions]
				, [Extent1].[InternalComments] AS [InternalComments]
				, [Extent1].[TotalDryItems] AS [TotalDryItems]
				, [Extent1].[TotalChillerItems] AS [TotalChillerItems]
				, [Extent1].[DeliveryRun] AS [DeliveryRun1]
				, [Extent1].[RunPosition] AS [RunPosition1]
				, [Extent1].[ReturnedDeliveryData] AS [ReturnedDeliveryData]
				, [Extent1].[ConfirmedDeliveryTime] AS [ConfirmedDeliveryTime]
				, [Extent1].[ConfirmedReceivedBy] AS [ConfirmedReceivedBy]
				, [Extent1].[LastEditedBy] AS [LastEditedBy1]
				, [Extent1].[LastEditedWhen] AS [LastEditedWhen]
				, [Extent2].[CustomerID] AS [CustomerID2]
				, [Extent2].[CustomerName] AS [CustomerName]
				, [Extent2].[BillToCustomerID] AS [BillToCustomerID2]
				, [Extent2].[CustomerCategoryID] AS [CustomerCategoryID]
				, [Extent2].[BuyingGroupID] AS [BuyingGroupID]
				, [Extent2].[PrimaryContactPersonID] AS [PrimaryContactPersonID]
				, [Extent2].[AlternateContactPersonID] AS [AlternateContactPersonID]
				, [Extent2].[DeliveryMethodID] AS [DeliveryMethodID2]
				, [Extent2].[DeliveryCityID] AS [DeliveryCityID]
				, [Extent2].[PostalCityID] AS [PostalCityID]
				, [Extent2].[CreditLimit] AS [CreditLimit]
				, [Extent2].[AccountOpenedDate] AS [AccountOpenedDate]
				, [Extent2].[StandardDiscountPercentage] AS [StandardDiscountPercentage]
				, [Extent2].[IsStatementSent] AS [IsStatementSent]
				, [Extent2].[IsOnCreditHold] AS [IsOnCreditHold]
				, [Extent2].[PaymentDays] AS [PaymentDays]
				, [Extent2].[PhoneNumber] AS [PhoneNumber]
				, [Extent2].[FaxNumber] AS [FaxNumber]
				, [Extent2].[DeliveryRun] AS [DeliveryRun2]
				, [Extent2].[RunPosition] AS [RunPosition2]
				, [Extent2].[WebsiteURL] AS [WebsiteURL]
				, [Extent2].[DeliveryAddressLine1] AS [DeliveryAddressLine1]
				, [Extent2].[DeliveryAddressLine2] AS [DeliveryAddressLine2]
				, [Extent2].[DeliveryPostalCode] AS [DeliveryPostalCode]
				, [Extent2].[DeliveryLocation] AS [DeliveryLocation]
				, [Extent2].[PostalAddressLine1] AS [PostalAddressLine1]
				, [Extent2].[PostalAddressLine2] AS [PostalAddressLine2]
				, [Extent2].[PostalPostalCode] AS [PostalPostalCode]
				, [Extent2].[LastEditedBy] AS [LastEditedBy2]
				, [Extent2].[ValidFrom] AS [ValidFrom1]
				, [Extent2].[ValidTo] AS [ValidTo1]
				, [Extent3].[DeliveryMethodID] AS [DeliveryMethodID3]
				, [Extent3].[DeliveryMethodName] AS [DeliveryMethodName]
				, [Extent3].[LastEditedBy] AS [LastEditedBy3]
				, [Extent3].[ValidFrom] AS [ValidFrom2]
				, [Extent3].[ValidTo] AS [ValidTo2]
            FROM   [Sales].[Invoices] AS [Extent1]
            INNER JOIN [Sales].[Customers] AS [Extent2] ON [Extent1].[BillToCustomerID] = [Extent2].[CustomerID]
            INNER JOIN [Application].[DeliveryMethods] AS [Extent3] ON [Extent1].[DeliveryMethodID] = [Extent3].[DeliveryMethodID] ---) AS [Limit1]

)
SELECT
	CTE.*,
			 [Extent4].[CustomerTransactionID] AS [CustomerTransactionID], 
        [Extent4].[CustomerID] AS [CustomerID2], 
        [Extent4].[TransactionTypeID] AS [TransactionTypeID], 
        [Extent4].[InvoiceID] AS [InvoiceID2], 
        [Extent4].[PaymentMethodID] AS [PaymentMethodID], 
        [Extent4].[TransactionDate] AS [TransactionDate], 
        [Extent4].[AmountExcludingTax] AS [AmountExcludingTax], 
        [Extent4].[TaxAmount] AS [TaxAmount], 
        [Extent4].[TransactionAmount] AS [TransactionAmount], 
        [Extent4].[OutstandingBalance] AS [OutstandingBalance], 
        [Extent4].[FinalizationDate] AS [FinalizationDate], 
        [Extent4].[IsFinalized] AS [IsFinalized], 
        [Extent4].[LastEditedBy] AS [LastEditedBy3], 
        [Extent4].[LastEditedWhen] AS [LastEditedWhen1], 
		CAST(NULL AS int) AS [InvoiceLineID], 
        CAST(NULL AS int) AS [InvoiceID2], 
        CAST(NULL AS int) AS [StockItemID], 
        CAST(NULL AS varchar(1)) AS [Description], 
        CAST(NULL AS int) AS [PackageTypeID], 
        CAST(NULL AS int) AS [Quantity], 
        CAST(NULL AS decimal(18,2)) AS [UnitPrice], 
        CAST(NULL AS decimal(18,2)) AS [TaxRate], 
        CAST(NULL AS decimal(18,2)) AS [TaxAmount], 
        CAST(NULL AS decimal(18,2)) AS [LineProfit], 
        CAST(NULL AS decimal(18,2)) AS [ExtendedPrice], 
        CAST(NULL AS int)  AS [LastEditedBy3], 
        CAST(NULL AS datetime2) AS [LastEditedWhen1], 
		CAST(NULL AS int) AS [StockItemTransactionID], 
        CAST(NULL AS int) AS [StockItemID], 
        CAST(NULL AS int) AS [TransactionTypeID], 
        CAST(NULL AS int) AS [CustomerID2], 
        CAST(NULL AS int) AS [InvoiceID2], 
        CAST(NULL AS int) AS [SupplierID], 
        CAST(NULL AS int) AS [PurchaseOrderID], 
        CAST(NULL AS datetime2) AS [TransactionOccurredWhen], 
        CAST(NULL AS decimal(18,3)) AS [Quantity], 
        CAST(NULL AS int) AS [LastEditedBy3], 
        CAST(NULL AS datetime2) AS [LastEditedWhen1]
FROM CTE
LEFT JOIN Sales.CustomerTransactions Extent4 ON CTE.InvoiceID = Extent4.InvoiceID

UNION ALL

SELECT
	CTE.*,
			CAST(NULL AS int) AS [CustomerTransactionID], 
        CAST(NULL AS int) AS [CustomerID2], 
        CAST(NULL AS int) AS [TransactionTypeID], 
        CAST(NULL AS int) AS [InvoiceID2], 
        CAST(NULL AS int) AS [PaymentMethodID], 
        CAST(NULL AS datetime2) AS [TransactionDate], 
        CAST(NULL AS decimal(18,2)) AS [AmountExcludingTax], 
        CAST(NULL AS decimal(18,2)) AS [TaxAmount], 
        CAST(NULL AS decimal(18,2)) AS [TransactionAmount], 
        CAST(NULL AS decimal(18,2)) AS [OutstandingBalance], 
        CAST(NULL AS datetime2) AS [FinalizationDate], 
        CAST(NULL AS int) AS [IsFinalized], 
        CAST(NULL AS int) AS [LastEditedBy3], 
        CAST(NULL AS datetime2) AS [LastEditedWhen1], 
        [Extent8].[InvoiceLineID] AS [InvoiceLineID], 
        [Extent8].[InvoiceID] AS [InvoiceID2], 
        [Extent8].[StockItemID] AS [StockItemID], 
        [Extent8].[Description] AS [Description], 
        [Extent8].[PackageTypeID] AS [PackageTypeID], 
        [Extent8].[Quantity] AS [Quantity], 
        [Extent8].[UnitPrice] AS [UnitPrice], 
        [Extent8].[TaxRate] AS [TaxRate], 
        [Extent8].[TaxAmount] AS [TaxAmount], 
        [Extent8].[LineProfit] AS [LineProfit], 
        [Extent8].[ExtendedPrice] AS [ExtendedPrice], 
        [Extent8].[LastEditedBy] AS [LastEditedBy3], 
        [Extent8].[LastEditedWhen] AS [LastEditedWhen1], 
		CAST(NULL AS int) AS [StockItemTransactionID], 
        CAST(NULL AS int) AS [StockItemID], 
        CAST(NULL AS int) AS [TransactionTypeID], 
        CAST(NULL AS int) AS [CustomerID2], 
        CAST(NULL AS int) AS [InvoiceID2], 
        CAST(NULL AS int) AS [SupplierID], 
        CAST(NULL AS int) AS [PurchaseOrderID], 
        CAST(NULL AS datetime2) AS [TransactionOccurredWhen], 
        CAST(NULL AS decimal(18,3)) AS [Quantity], 
        CAST(NULL AS int) AS [LastEditedBy3], 
        CAST(NULL AS datetime2) AS [LastEditedWhen1]
FROM CTE
INNER JOIN Sales.InvoiceLines Extent8 ON CTE.InvoiceID = Extent8.InvoiceID

UNION ALL

SELECT
	CTE.*,
	CAST(NULL AS int) AS [CustomerTransactionID], 
        CAST(NULL AS int) AS [CustomerID2], 
        CAST(NULL AS int) AS [TransactionTypeID], 
        CAST(NULL AS int) AS [InvoiceID2], 
        CAST(NULL AS int) AS [PaymentMethodID], 
        CAST(NULL AS datetime2) AS [TransactionDate], 
        CAST(NULL AS decimal(18,2)) AS [AmountExcludingTax], 
        CAST(NULL AS decimal(18,2)) AS [TaxAmount], 
        CAST(NULL AS decimal(18,2)) AS [TransactionAmount], 
        CAST(NULL AS decimal(18,2)) AS [OutstandingBalance], 
        CAST(NULL AS datetime2) AS [FinalizationDate], 
        CAST(NULL AS int) AS [IsFinalized], 
        CAST(NULL AS int) AS [LastEditedBy3], 
        CAST(NULL AS datetime2) AS [LastEditedWhen1], 
		CAST(NULL AS int) AS [InvoiceLineID], 
        CAST(NULL AS int) AS [InvoiceID2], 
        CAST(NULL AS int) AS [StockItemID], 
        CAST(NULL AS varchar(1)) AS [Description], 
        CAST(NULL AS int) AS [PackageTypeID], 
        CAST(NULL AS int) AS [Quantity], 
        CAST(NULL AS decimal(18,2)) AS [UnitPrice], 
        CAST(NULL AS decimal(18,2)) AS [TaxRate], 
        CAST(NULL AS decimal(18,2)) AS [TaxAmount], 
        CAST(NULL AS decimal(18,2)) AS [LineProfit], 
        CAST(NULL AS decimal(18,2)) AS [ExtendedPrice], 
        CAST(NULL AS int)  AS [LastEditedBy3], 
        CAST(NULL AS datetime2) AS [LastEditedWhen1],  
        [Extent12].[StockItemTransactionID] AS [StockItemTransactionID], 
        [Extent12].[StockItemID] AS [StockItemID], 
        [Extent12].[TransactionTypeID] AS [TransactionTypeID], 
        [Extent12].[CustomerID] AS [CustomerID2], 
        [Extent12].[InvoiceID] AS [InvoiceID2], 
        [Extent12].[SupplierID] AS [SupplierID], 
        [Extent12].[PurchaseOrderID] AS [PurchaseOrderID], 
        [Extent12].[TransactionOccurredWhen] AS [TransactionOccurredWhen], 
        [Extent12].[Quantity] AS [Quantity], 
        [Extent12].[LastEditedBy] AS [LastEditedBy3], 
        [Extent12].[LastEditedWhen] AS [LastEditedWhen1]
FROM CTE
INNER JOIN Warehouse.StockItemTransactions Extent12 ON CTE.InvoiceID = Extent12.InvoiceID
