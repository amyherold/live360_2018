--set statistics io on
--set statistics time on
use WWI;

;with x as (select count(ol.OrderID) order_count, ol.OrderID
from sales.OrderLines ol
group by ol.OrderID)
select top 1000 orderid
into #orders
from x
order by order_count desc

--select * from #orders



select ol.OrderID, ol.StockItemID
,si.unitprice
, si.RecommendedRetailPrice
,ol.Quantity
,ol.PickedQuantity
,il.TaxRate
,il.TaxAmount
,il.LineProfit
,(il.taxrate/100)+1 as taxmultiplier
,il.Quantity * il.UnitPrice as totalprice
,(il.Quantity * il.UnitPrice)*((il.taxrate/100)+1) as totalpriceplustax
,convert(decimal(18,2),(il.Quantity * il.UnitPrice)*((il.taxrate/100)+1)) as totalpriceplustax2
from sales.OrderLines ol
join sales.Orders o on ol.OrderID = o.OrderID
join #orders oo on ol.orderid = oo.orderid
left outer join Warehouse.StockItems si on ol.StockItemID = si.StockItemID
left outer join sales.Invoices i on o.OrderID = i.OrderID
left outer join Sales.InvoiceLines il on i.InvoiceID = il.InvoiceID and ol.StockItemID = il.StockItemID
left outer join sales.CustomerTransactions ct on i.InvoiceID = ct.InvoiceID
order by 1,2



drop table #orders
