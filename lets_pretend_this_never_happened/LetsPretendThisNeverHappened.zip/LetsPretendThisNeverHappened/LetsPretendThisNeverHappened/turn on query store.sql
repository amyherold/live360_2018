-----------------turn on query store on AdventureWorks------------------
ALTER DATABASE [AdventureWorks] SET QUERY_STORE = ON
GO
ALTER DATABASE [AdventureWorks] 
SET QUERY_STORE (
       OPERATION_MODE   = READ_WRITE, 
       CLEANUP_POLICY   = (STALE_QUERY_THRESHOLD_DAYS = 31), 
       MAX_STORAGE_SIZE_MB   = 1024,
       DATA_FLUSH_INTERVAL_SECONDS   = 900,
       QUERY_CAPTURE_MODE   = AUTO, 
       INTERVAL_LENGTH_MINUTES   = 60,
       SIZE_BASED_CLEANUP_MODE   = AUTO
       )
GO