set statistics io on
set statistics time on

DECLARE @DealerDiscount money;
SET @DealerDiscount = 0.60  -- 60% of list price

--------------------------query with scalar function calls------------------------
select ---top 1000 
dbo.ufnGetProductDealerPrice(pod.productid, poh.OrderDate) ProductDealerPrice
,dbo.ufnGetProductListPrice(pod.productid, poh.OrderDate) ProductListPrice
,dbo.ufnGetProductStandardCost(pod.productid, poh.OrderDate) ProductStandardCost
,poh.*, pod.*
,pod.PurchaseOrderID
--into #test1
from Purchasing.PurchaseOrderHeader poh --	OrderDate
join Purchasing.PurchaseOrderDetail	pod  on poh.PurchaseOrderID = pod.PurchaseOrderID --ProductID



-------------------------------query with functions condensed into one CTE---------------------
;with CTE as 
(
SELECT pch.[StandardCost] 
,plph.[ListPrice] 
,plph.[ListPrice] * @DealerDiscount as DealerPrice
,p.ProductID
,plph.StartDate
,plph.EndDate
FROM [Production].[Product] p 
INNER JOIN [Production].[ProductCostHistory] pch ON p.[ProductID] = pch.[ProductID] 
INNER JOIN [Production].[ProductListPriceHistory] plph ON p.[ProductID] = plph.[ProductID] 
)
select 
cte.DealerPrice
,cte.ListPrice
,cte.StandardCost
,poh.*, pod.*
from Purchasing.PurchaseOrderHeader poh --	OrderDate
join Purchasing.PurchaseOrderDetail	pod  on poh.PurchaseOrderID = pod.PurchaseOrderID --ProductID
left outer join cte on pod.ProductID = CTE.ProductID 
	and poh.OrderDate BETWEEN CTE.[StartDate] AND COALESCE(CTE.[EndDate], CONVERT(datetime, '99991231', 112)); -- Make sure we get all the prices!





------------------------------query with all functions converted to CTEs----------------------------
;with dealer as
(
	SELECT plph.[ListPrice] * @DealerDiscount as DealerCost 
	,plph.[StartDate]
	,plph.[EndDate]
	,p.ProductID
	FROM [Production].[Product] p 
	INNER JOIN [Production].[ProductListPriceHistory] plph ON p.[ProductID] = plph.[ProductID] 
)
,listprice as
(
	SELECT plph.[ListPrice] 
	,plph.[StartDate]
	,plph.[EndDate]
	,p.ProductID
	FROM [Production].[Product] p 
	INNER JOIN [Production].[ProductListPriceHistory] plph ON p.[ProductID] = plph.[ProductID] 
)
, standardcost as
(
	SELECT pch.[StandardCost] 
	,pch.[StartDate]
	,pch.[EndDate]
	,p.ProductID
	FROM [Production].[Product] p 
	INNER JOIN [Production].[ProductCostHistory] pch ON p.[ProductID] = pch.[ProductID] 
)
,x as
(
select poh.[PurchaseOrderID],poh.[RevisionNumber]
      ,poh.[Status]
      ,poh.[EmployeeID]
      ,poh.[VendorID]
      ,poh.[ShipMethodID]
      ,poh.[OrderDate]
      ,poh.[ShipDate]
      ,poh.[SubTotal]
      ,poh.[TaxAmt]
      ,poh.[Freight]
      ,poh.[TotalDue]
      ,pod.[PurchaseOrderDetailID]
      ,pod.[DueDate]
      ,pod.[OrderQty]
      ,pod.[ProductID]
      ,pod.[UnitPrice]
      ,pod.[LineTotal]
      ,pod.[ReceivedQty]
      ,pod.[RejectedQty]
      ,pod.[StockedQty]
from Purchasing.PurchaseOrderHeader poh --	OrderDate
join Purchasing.PurchaseOrderDetail	pod  on poh.PurchaseOrderID = pod.PurchaseOrderID --ProductID
)
select distinct
dealer.DealerCost
,listprice.ListPrice
,standardcost.StandardCost
,x.*
from x
left outer join standardcost on x.ProductID = standardcost.ProductID
and x.OrderDate BETWEEN standardcost.[StartDate] AND COALESCE(standardcost.[EndDate], CONVERT(datetime, '99991231', 112))
left outer join dealer on x.ProductID = dealer.ProductID
and x.OrderDate BETWEEN dealer.[StartDate] AND COALESCE(dealer.[EndDate], CONVERT(datetime, '99991231', 112))
left outer join listprice on x.ProductID = listprice.ProductID
and x.OrderDate BETWEEN listprice.[StartDate] AND COALESCE(listprice.[EndDate], CONVERT(datetime, '99991231', 112)); -- Make sure we get all the prices!
