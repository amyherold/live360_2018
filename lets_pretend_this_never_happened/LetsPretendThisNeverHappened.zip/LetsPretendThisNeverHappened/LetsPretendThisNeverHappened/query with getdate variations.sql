Use WWI
go

set statistics io on
set statistics time on

/*
SET SHOWPLAN_TEXT OFF
go
SET SHOWPLAN_ALL OFF
go
SET SHOWPLAN_XML OFF
go

SET STATISTICS PROFILE OFF
SET STATISTICS XML OFF
*/

-----------------select all from Purchasing.PurchaseOrders-----------
select po.*
from Purchasing.PurchaseOrders po

-----------------select all from Purchasing.PurchaseOrders with getdate-----------
select getdate() as Today,po.*
from Purchasing.PurchaseOrders po

-----------------select all from Purchasing.PurchaseOrders with the view CurrentDate-----------
select cd.*,po.*
from Purchasing.PurchaseOrders po
outer apply CurrentDate cd

-----------------select all from Purchasing.PurchaseOrders with the view CurrentDate-----------
declare @date datetime
set @date = getdate()

select @date AS Today,po.*
from Purchasing.PurchaseOrders po
