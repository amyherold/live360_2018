﻿Import-Module 'C:\Users\Amy\Desktop\summit2018\session4\PS\get-permissions.ps1';
Import-Module 'C:\Users\Amy\Desktop\summit2018\session4\PS\apply-permissions.ps1';


$server = 'SQLKITTEN-II\SQLSERVER2017';
$database = 'AdventureWorks';

#-------------------------------------get permissions--------------------------------------------
#get-permissions -server $server -database $database;


#-------------------------------------apply permissions--------------------------------------------
Apply-Permissions -server $server -database $database