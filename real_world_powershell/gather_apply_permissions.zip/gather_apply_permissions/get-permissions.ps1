﻿function global:Get-Permissions{

PARAM(

[parameter(ValueFromPipeline=$True,ValueFromPipelineByPropertyName=$True,Position=0)]
[string]$server
,[parameter(ValueFromPipeline=$True,ValueFromPipelineByPropertyName=$True,Position=1)]
[string]$database

)

$repository_server = 'SQLKITTEN-II\SQLSERVER2017';

#--------------------get list of databases on the server---------------
<#
$DatabaseNames = $null;#@('Pricing')

$get_databases = "select name from sys.databases where name not in ('master','tempdb','msdb','model')";
if ($DatabaseNames -eq $null)
{
    $DatabaseNames = (Invoke-Sqlcmd -ServerInstance $server -Database master -Query $get_databases);

}

#$DatabaseNames
#>
#------------------for each database, get permissions and write to table--------------------------
#foreach ($d in $DatabaseNames)
#{    
    $database_name = $database;#$d.name;


    $logins = Export-DbaLogin -SqlInstance $server -NoDatabases
    $users = Export-DbaUser -SqlServer $server -Database $database_name

    
    #$logins = Export-DbaLogin -SqlInstance $server -Database $database_name -ExcludeLogin 'dbo';
    $logins = $logins + "`r`n`r`n`r`n" + $users;
    $logins = $logins -replace "'","''";


    $insert_logins = "INSERT INTO DBA.dbo.DatabasePermission (InstanceName,DatabaseName,PermissionScript) VALUES ('$server','$database_name','$logins')";
    $insert_logins

    Invoke-Sqlcmd -ServerInstance "$repository_server" -Database DBA -Query $insert_logins;



#}

}#end of cmdlet function


