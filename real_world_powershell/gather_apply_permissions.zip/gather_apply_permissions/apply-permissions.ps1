﻿function global:Apply-Permissions{

PARAM(

[parameter(ValueFromPipeline=$True,ValueFromPipelineByPropertyName=$True,Position=0)]
[string]$server

,[parameter(ValueFromPipeline=$True,ValueFromPipelineByPropertyName=$True,Position=1)]
[string]$database

)


$repository_server = 'SQLKITTEN-II\SQLSERVER2017';

#----------------this is the script to fix all orphaned logins----------------------
$loginfix = 'DECLARE @Username VARCHAR(128),
        @cmd      VARCHAR(256)

DECLARE userlogin_cursor CURSOR FAST_FORWARD LOCAL  FOR
SELECT  
	name
 FROM   
	sysusers
WHERE  
	issqluser = 1
    AND (sid IS NOT NULL
          AND sid <> 0x01)
    AND Suser_sname(sid) IS NULL
	AND name NOT IN (''guest'',''dbo'')
ORDER  BY 
	name
 

OPEN userlogin_cursor
FETCH NEXT FROM userlogin_cursor INTO @Username

WHILE @@FETCH_STATUS = 0
  BEGIN
      SET @cmd = ''ALTER USER ['' + @username + ''] WITH LOGIN = ['' + @username + '']''
      RAISERROR(@cmd,10,1) WITH NOWAIT;
	  EXECUTE(@cmd)
      FETCH NEXT FROM userlogin_cursor INTO @Username
  END

CLOSE userlogin_cursor
DEALLOCATE userlogin_cursor '


#[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
#
#Add-PSSnapin -Name SqlServerCmdletSnapin100;
#Add-PSSnapin -Name SqlServerProviderSnapin100;

#$SQLInstanceName = $server;

#$SQLInstance = New-Object "Microsoft.SqlServer.Management.Smo.Server" $SQLInstanceName;
#$db = New-Object "Microsoft.SQLServer.Management.Smo.Database";



#foreach ($database in $DatabaseNames)
#{

    $get_perms = "select top 1 PermissionScript as perms 
                    from DatabasePermission
                    where InstanceName = '$server'
                    and DatabaseName = '$database'
                    order by CreatedOn desc";
    #$get_perms;
        
    $perms = (Invoke-Sqlcmd -ServerInstance "$repository_server" -Database DBA -Query $get_perms -MaxCharLength 8000000).perms;

    #$perms;
    Invoke-Sqlcmd -ServerInstance "$server" -Database $database -Query $perms;
    #auto fix any orphaned users.
    Invoke-Sqlcmd -ServerInstance "$server" -Database $database -Query $loginfix -Verbose;
    


#}




#-----------------------------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------------------





#-----------------------get permissions for a specific server and database and apply them---------------------



#--------------------get list of databases on the server---------------
<#
$DatabaseNames = $null;#@('Pricing')

$get_databases = "select name from sys.databases where name not in ('master','tempdb','msdb','model')";
if ($DatabaseNames -eq $null)
{
    $DatabaseNames = (Invoke-Sqlcmd -ServerInstance $server -Database master -Query $get_databases);

}

#$DatabaseNames

#------------------for each database, get permissions and write to table--------------------------
foreach ($d in $DatabaseNames)
{    
    $database_name = $d.name;
    
    $logins = Export-DbaLogin -SqlInstance $server -Database $database_name;
    $logins = $logins -replace "'","''"

    $insert_logins = "INSERT INTO DBAConsole.dbo.DatabasePermission (InstanceName,DatabaseName,PermissionScript) VALUES ('$server','$database_name','$logins')";

    Invoke-Sqlcmd -ServerInstance $repository_server -Database DBAConsole -Query $insert_logins;



}#>

}#end of cmdlet function