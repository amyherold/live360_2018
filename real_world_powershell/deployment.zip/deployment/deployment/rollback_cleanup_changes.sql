USE [StackOverflow]
GO


alter procedure [dbo].[usp_upd_posts_createdate]
as
begin
	Begin Tran
		update Posts_10M
		set creationdate = CURRENT_TIMESTAMP
		where id = 26

		select displayname
		from Users				
		order by displayname
		option (MAXDOP 1)
		
	commit
		
end
GO





alter procedure [dbo].[usp_upd_users]
as
begin
	Begin Tran
		update users
		set downvotes = 50
		where id = 16

		select LastEditorDisplayName
		from Posts_10M
		order by LastEditorDisplayName

	commit
		
end
GO



drop view vw_LinkTypes
go
drop view vw_VoteTypes
go
drop view vw_PostTypes
go
drop view vw_PostTags
go
drop view vw_Votes
go
drop view vw_Users
go
drop view vw_Posts
go
drop view vw_Comments
go
drop view vw_Badges
go
drop view vw_PostLinks
go
drop view vw_Posts_10M
go



