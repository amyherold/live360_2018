USE [DBA]
GO

alter table [dbo].[Deployments]
alter column Author varchar(50)

truncate table [dbo].[Deployments]


INSERT INTO [dbo].[Deployments](TicketID,OrderOfExec,ServerID,[Database],Author,Script,Notes)
VALUES
('DB-1234',1,1,'StackOverflow','AmyHerold','Stackoverflow\sql\usp_upd_posts_createdate.sql','update proc')
,('DB-1234',2,1,'StackOverflow','AmyHerold','Stackoverflow\sql\usp_upd_users.sql','update proc')
,('DB-1234',3,1,'BrentOzarWasHere','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_LinkTypes.sql','create view')
,('DB-1234',4,1,'BrentOzarWasHere','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_VoteTypes.sql','create view')
,('DB-1234',5,1,'BrentOzarWasHere','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_PostTypes.sql','create view')
,('DB-1234',6,1,'DavidKleeForPresident','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_PostTags.sql','create view')
,('DB-1234',7,1,'DavidKleeForPresident','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_Votes.sql','create view')
,('DB-1234',8,1,'DavidKleeForPresident','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_Users.sql','create view')
,('DB-1234',9,1,'DavidKleeForPresident','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_Posts.sql','create view')
,('DB-1234',10,1,'DavidKleeForPresident','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_Comments.sql','create view')
,('DB-1234',11,1,'StackOverflow','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_Badges.sql','create view')
,('DB-1234',12,1,'StackOverflow','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_PostLinks.sql','create view')
,('DB-1234',13,1,'StackOverflow','Joe "I write SQL GOOD" Developer','Stackoverflow\sql\vw_Posts_10M.sql','create view')





GO



select * from deployments


update deployments
set [database] = 'BrentOzarWasHere'
where id in (3
,4
,5) 



update deployments
set [database] = 'DavidKleeForPresident'
where id in (6
,7
,8
,9
,10)


select @@SERVERNAME
