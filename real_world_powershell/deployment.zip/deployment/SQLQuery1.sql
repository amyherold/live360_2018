SELECT [ReleaseTicket]
      ,[OrderOfExec]
      ,[ServerID]
      ,[DBName]
      ,[Script]
 FROM [Deployments].[dbo].[ReleaseData]
 WHERE ReleaseTicket = 'REL-$release'
 ORDER BY OrderOfExec

drop table DBA..ReleaseData


 create table DBA..ReleaseData (id int identity(1,1)
,ReleaseTicket varchar(50)
 ,OrderOfExec int
 ,ServerID varchar(50)
 ,DBName varchar(100)
 ,Script varchar(500))




 insert DBA..ReleaseData(ReleaseTicket
 ,OrderOfExec,ServerID
 ,DBName
 ,Script)
 values ('REL-1234',0,'SQLKITTEN-II\SQLSERVER2017','StackOverflow','StackOverflow\sql\usp_upd_posts_createdate.sql')
 ,('REL-1234',1,'SQLKITTEN-II\SQLSERVER2017','StackOverflow','StackOverflow\sql\usp_upd_users.sql')

 
 insert DBA..ReleaseData(ReleaseTicket
 ,OrderOfExec,ServerID
 ,DBName
 ,Script)
 values ('REL-1235',0,'SQLKITTEN-II\SQLSERVER2017','StackOverflow','StackOverflow\sql\usp_upd_posts_createdate.sql')
 ,('REL-1235',1,'SQLKITTEN-II\SQLSERVER2017','StackOverflow','StackOverflow\sql\usp_upd_users.sql')


  insert DBA..ReleaseData(ReleaseTicket
 ,OrderOfExec,ServerID
 ,DBName
 ,Script)
 values ('REL-1236',0,'SQLKITTEN-II\SQLSERVER2017','StackOverflow','StackOverflow\sql\usp_upd_posts_createdate.sql')
 ,('REL-1236',1,'SQLKITTEN-II\SQLSERVER2017','StackOverflow','StackOverflow\sql\usp_upd_users.sql')



 select * from dba..ReleaseData
